---
name: Bug report
about: Create a report to help us improve
title: "[BUG / possible BUG]"
labels: 'bug:to be reproduced,bug:needs triage/confirmation'
assignees: ''

---
<!---

_Feel free to remove this line but please stick to the template. We would like to reproduce the bug and therefore need concise information. Depending on the lack of information provided we might close your issue otherwise right away. _
-->

**General remark**

It's much appreciated if you spot bugs and file them! Please keep in mind though that you'd need to enable us to reproduce what you encountered. If otherwise we need to play ping-pong it costs time on our side we'd rather like to spend on the development. 

**Before you open an issue please check which version you are running and whether it is the latest in stable / dev branch**

- [ ] I am running version (``git log | head -1`` ) from the git repo 
- [ ] I am running ``testssl.sh -v | grep from``


**Before you open an issue please consult the [FAQ](https://github.com/testssl/testssl.sh/blob/3.3dev/FAQ.md) and check whether this is a known problem by searching the  [issues](https://github.com/testssl/testssl.sh/issues)**

- [ ] Is related to ...
- [ ] couldn't find anything


**Command line to reproduce (or docker command)**

Which was your command line? In addition the target of your scan is often needed to reproduce what happened. If you don't want to disclose it publicly: ``grep SWCONTACT testssl.sh``. 


**Expected behavior**

A clear and concise description of what you would expect to happen instead.


**Your system (please complete the following information):**
 - OS: ``awk -F\" '/PRETTY_NAME/ { print $2 }' /etc/os-release``
 - Platform: ``uname -srm``
 - OpenSSL + bash: ``testssl.sh -b 2>/dev/null | grep Using``

**Additional context**

Any other context about the problem goes here.
